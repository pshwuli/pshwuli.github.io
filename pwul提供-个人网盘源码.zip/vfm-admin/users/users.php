<?php

 $_USERS = array (
  0 => 
  array (
    'name' => 'admin',
    'pass' => '$1$lI7ggM5Z$jMAg6DdGleond9kOJzAxQ0',
    'role' => 'superadmin',
  ),
);
