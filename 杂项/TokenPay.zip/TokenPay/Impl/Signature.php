<?php
declare(strict_types=1);

namespace App\Pay\TokenPay\Impl;

/**
 * Class Signature
 * @package App\Pay\TokenPay\Impl
 */
class Signature implements \App\Pay\Signature
{

    /**
     * 生成签名
     * @param array $data
     * @param string $key
     * @return string
     */
    public static function generateSignature(array $data, string $key): string
    {
        ksort($data);
        $sign = '';
        foreach ($data as $k => $v) {
            if ($v !== null && $v !== '') {
                $sign .= $k . '=' . $v . '&';
            }
        }
        $sign = rtrim($sign, '&');
        return md5($sign . $key);
    }

    /**
     * @inheritDoc
     */
    public function verification(array $data, array $config): bool
    {
        $sign = $data['Signature'] ?? '';
        unset($data['Signature']);
        $generateSignature = self::generateSignature($data, $config['key']);
        return $sign === $generateSignature;
    }
}