<?php
declare(strict_types=1);

namespace App\Pay\TokenPay\Impl;

use App\Entity\PayEntity;
use App\Pay\Base;
use GuzzleHttp\Exception\GuzzleException;
use Kernel\Exception\JSONException;

/**
 * Class Pay
 * @package App\Pay\TokenPay\Impl
 */
class Pay extends Base implements \App\Pay\Pay
{

    /**
     * @return PayEntity
     * @throws JSONException
     */
    public function trade(): PayEntity
    {

        if (!$this->config['url']) {
            throw new JSONException("请配置网关地址");
        }

        if (!$this->config['key']) {
            throw new JSONException("请配置密钥");
        }

        $param = [
            'OutOrderId' => $this->tradeNo,
            'OrderUserKey' => $this->tradeNo,
            'ActualAmount' => $this->amount,
            'Currency' => 'USDT_TRC20',
            'NotifyUrl' => $this->callbackUrl,
            'RedirectUrl' => $this->returnUrl
        ];

        $param['Signature'] = Signature::generateSignature($param, $this->config['key']);

        try {
            $request = $this->http()->post(rtrim($this->config['url'], "/") . '/CreateOrder', [
                "json" => $param
            ]);
        } catch (GuzzleException $e) {
            throw new JSONException("网关连接失败，下单未成功");
        }

        $contents = $request->getBody()->getContents();
        $json = (array)json_decode((string)$contents, true);

        if (!$json['success']) {
            throw new JSONException((string)$json['message']);
        }

        $payEntity = new PayEntity();
        $payEntity->setType(self::TYPE_REDIRECT);
        $payEntity->setUrl($json['data']);
        return $payEntity;
    }
}